from openai import OpenAI

class TravelAgent:
    def __init__(self, api_key):
        self.client = OpenAI(api_key=api_key)

    def chat(self, message):
        system_prompt = """
You are a conversational travel planning assistant.
"""
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role":"system","content":system_prompt},
                {"role":"user","content":message}
            ]
        )
        return response.choices[0].message["content"]
