import json

def load_api_keys(path="config.json"):
    with open(path,"r") as f:
        return json.load(f)
