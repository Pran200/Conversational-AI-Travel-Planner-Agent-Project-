from agents.travel_agent import TravelAgent
from utils.loader import load_api_keys

def main():
    keys = load_api_keys()
    agent = TravelAgent(api_key=keys["OPENAI_API_KEY"])

    print("\n--- Conversational AI Travel Planner Agent ---\n")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit","quit","bye"]:
            print("Agent: Safe travels! 👋")
            break
        print("Agent:", agent.chat(user_input))

if __name__ == "__main__":
    main()
